#!/bin/sh -
latex badros.tex
./mybibtex badros
latex badros.tex
latex badros.tex
dvips -t letter -o badros-f.ps badros.dvi
